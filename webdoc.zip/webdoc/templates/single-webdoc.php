<!DOCTYPE html>
<html lang="fr">
<head>
	<meta name="msapplication-config" content="none"/>
	<meta charset="utf-8" />
	<title><?php bloginfo('name'); ?> <?php wp_title('-'); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="robots" content="all" />
	<meta name="revisit-After" content="1 day" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta property="og:type" content="article"> 
	<meta property="og:site_name" content="<?php the_title(); ?>">
	<meta property="og:determiner" content="auto">
	<meta property="og:locale" content="en-EN"> 
	<meta property="og:website" content="<?php the_permalink(); ?>"> 
	<meta property="og:profile" content="<?php the_permalink(); ?>"> 
	<meta property="og:title" content="<?php the_title(); ?>"> 
	<meta name="og:url" content="<?php the_permalink(); ?>">
	<meta property="og:description" content="<?php get_the_excerpt(); ?>"> 
	<meta name="twitter:card" value="summary_large_image"> 
	<meta property="twitter:title" content="<?php the_title(); ?>"> 
	<meta name="twitter:url" content="<?php the_permalink(); ?>"> 
	<meta property="twitter:image" content="<?php echo get_the_post_thumbnail_url(); ?>">
	<meta property="og:image" content="<?php echo get_the_post_thumbnail_url(); ?>"> 	
	<meta property="twitter:description" content="<?php get_the_excerpt(); ?>"> 
	<meta name="DC.Publisher" content=" ">
	<meta name="DC.Date" content="2022-02-15">
	<meta name="DC.Language" scheme="UTF-8" content="en-EN">
	<meta name="DC.Subject" content="Webdocumentary">
	<meta name="DC.Creator" content=""> 
	<meta name="DC.Identifier" content="<?php the_permalink(); ?>">
	<meta property="DC.Title" content="<?php the_title(); ?>"> 
	<meta property="DC.Description" content="<?php get_the_excerpt(); ?>"> 
	
	<?php 
		wp_head(); 
		include('single-header.php');
	?>
</head>
<body>

<?php 
if ( has_post_parent() ) { 
		
	include('content-page.php');

}
else {

	include('content-home.php');

	//get_the_title( $page_id );

} 

$footer = get_post_meta( get_the_ID(), '_wp_editor_foot', true );
if( !empty( $footer ) ) : ?> 
		<footer id="footer">
			<div id="footer_lf" class="container col-md-12"> 
				<?php echo apply_filters('the_content', $footer); ?> 
			</div> 
		</footer> 
<?php endif; ?>

<?php  
	wp_footer(); 
	

if ( has_post_parent() ) :  
	if ($n > 4):  ?>
	
	<script type='text/javascript'>
		 if ($(window).width() > 767) {
			jQuery('.slick').slick({
				  slidesToShow: 4,
				  slidesToScroll: 1,
				  autoplay: false,
				  infinite: true,
				  autoplaySpeed: 2000,
				  prevArrow: '<button class="slide-arrow prev-arrow"><i class="ion ion-chevron-left"></button>',
				  nextArrow: '<button class="slide-arrow next-arrow"><i class="ion ion-chevron-right"></button>',
					responsive: [
						{
						  breakpoint: 1024,
							  settings: {
								slidesToShow: 3,
								slidesToScroll: 1
							  }
						},
						{
						  breakpoint: 769,
							  settings: {
								slidesToShow: 1,
								slidesToScroll: 1
							  }
						}
					]
			});
		 }
	</script>

<?php 
	endif;
	else : 
	if ($n > 4): ?>
<script type='text/javascript'>
 if ($(window).width() > 767) {
	jQuery('.slick').slick({
		  slidesToShow: 4,
		  slidesToScroll: 1,
		  autoplay: false,
		  infinite: true,
		  autoplaySpeed: 2000,
		  prevArrow: '<button class="slide-arrow prev-arrow"><i class="ion ion-chevron-left"></button>',
		  nextArrow: '<button class="slide-arrow next-arrow"><i class="ion ion-chevron-right"></button>',
			responsive: [
				{
				  breakpoint: 1024,
					  settings: {
						slidesToShow: 2,
						slidesToScroll: 2
					  }
				},
				{
				  breakpoint: 769,
					  settings: {
						slidesToShow: 1,
						slidesToScroll: 1
					  }
				}
			]
	});
 }
</script>
<?php endif; ?>
<?php endif; ?>
</body>
</html>
<div id="overlay"></div>
<nav id="menu">
	<div class="container">
			<div id="open">
				<span class="ion ion-navicon-round"></span>
			</div>
			
			<div id="closed" style="display: none;">
				<span class="ion ion-close"></span>
			</div>
			
			<div id="float-right">
				<ul>
				<li>
					<a target="_blank" href="https://twitter.com/intent/tweet?url=<?php  the_permalink(); ?>&text=<?php the_title(); ?>">			
					<span class="ion ion-social-twitter"></span>
					</a>
				</li>
				<li>				
					<a href="http://www.facebook.com/sharer.php?u=<?php  the_permalink(); ?>&t=<?php the_title(); ?>" target="blank">
					<span class="ion ion-social-facebook"></span>
					</a>
				</li>
				</ul>
			</div>
		</div>
</nav>

<div id="menuleft" class="menuhome">
	
	<h3><?php the_title(); ?></h3>
	<ul class="navbar-nav mr-auto float-left">
	<li class="nav-item">
	<?php 
		$page_id = get_queried_object_id();
		$n = 1;
		$args = array(
			'post_parent' => $page_id,
			'post_type' => 'webdoc',
			'orderby' => 'menu_order',
			'order' => 'ASC'
		);

		$child_query = new WP_Query( $args );
		while ( $child_query->have_posts() ) : $child_query->the_post(); ?>
			<a class="nav-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		<?php 
			$n = $n+1;
			endwhile;
			wp_reset_postdata();
		?>
		</li>
	</ul>
</div>
	
	<header id="section1">
		<div class="container">
			
			<div id="content1">
				<div id="table">
					<div id="table-cell">
						<div id="main-title">
							<?php if (empty($title) ) : ?>
							<h1><span><?php the_title(); ?></span></h1>	  
							<?php endif; ?>
						</div>
					</div>
				</div>
			
			</div>
		</div>
		<div id="more">
			<?php $arrow = get_post_meta(get_the_ID() , 'arrow', true); ?>	
			<a href="#section2" class="scrollTo">
			<?php if ($arrow == "select-one") { ?>
			<span class="ion ion-chevron-down"></span>
			<?php } elseif ($arrow == "select-two") { ?>
			<span class="ion ion-arrow-down-b"></span>
			<?php } elseif ($arrow == "select-three") { ?>
			<span class="ion ion-arrow-down-c"></span>
			<?php } elseif ($arrow == "select-four") { ?>
			<span class="ion ion-ios-arrow-down"></span>
			<?php } elseif ($arrow == "select-five") { ?>
			<span class="ion ion-ios-arrow-thin-down"></span>
			<?php } elseif ($arrow == "select-six") { ?>
			<span class="ion ion-android-arrow-dropdown-circle"></span>
			<?php } elseif ($arrow == "select-seven") { ?>
			<span class="ion-android-arrow-down"></span>
			<?php } elseif ($arrow == "select-eight") { ?>
			<span class="ion-ios-download"></span>
			<?php } else { ?>
			<span class="ion ion-ios-download-outline"></span>
			<?php } ?>
			</a>
		</div>
	</header>
	
	<article id="section2">
		<div class="<?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } elseif ($meta_col == "select-four") { echo $xs; } else { echo $medium; } ?> mx-auto">
			
			<?php 
				$title = get_post_meta( get_the_ID(), 'alaune_une', true );
				$chapeau = get_post_meta( get_the_ID(), 'chapeau', true );
			?>
			
			<?php  if ($title == "yes") : ?>
			<h1><?php the_title(); ?></h1>
			<?php  endif; 
			
				if ($chapeau == "yes") : 
					if ( has_excerpt() ) : ?>
						<div id="chapeau">
							  <?php the_excerpt(); ?>
						</div>
					<?php endif ; 
				endif;
			
				the_content(); ?>
			
		</div>
	</article>
	
	<div class="clear"></div>
			
	<section id="section3">		
		<div class="<?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } elseif ($meta_col == "select-four") { echo $xs; } else { echo $medium; } ?> mx-auto">
			<div class="row">	
			<div class="slick">
			<?php 
			
				$page_id = get_queried_object_id();
				
				$n = 1;
				
				$args = array(
					'post_parent' => $page_id,
					'post_type' => 'webdoc',
					'orderby' => 'menu_order',
					'order' => 'ASC'
				);

				$child_query = new WP_Query( $args );
				 while ( $child_query->have_posts() ) : $child_query->the_post(); ?>

					<div class="col-lg-3 col-md-4 col-sm-12">  
						<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>">
						<?php  
						if ( has_post_thumbnail() ) {
							the_post_thumbnail('webdoc');
						}
						?>
						</a>
						<h4><?php echo $chap . " " . $n; ?></h4>
						<h3><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
					</div>
				<?php 
					$n = $n+1;
					endwhile;
					wp_reset_postdata();
				?>
			</div>
			</div>
		</div>
	</section>
	<div class="clear"></div>
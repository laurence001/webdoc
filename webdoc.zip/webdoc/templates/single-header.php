<?php
$meta_font = get_post_meta(get_the_ID() , 'meta-font', true);
$meta_font_title = get_post_meta(get_the_ID() , 'meta-font_title', true);
$meta_font_size = get_post_meta( get_the_ID(), 'meta-font-size', true ); 
$body_color = get_post_meta( get_the_ID(), 'body-color', true ); 
$footer_color = get_post_meta( get_the_ID(), 'footer-color', true ); 
$text_footer_color = get_post_meta( get_the_ID(), 'text-footer-color', true ); 
$meta_color = get_post_meta( get_the_ID(), 'meta-color', true ); 
$meta_text_color = get_post_meta( get_the_ID(), 'meta-text-color', true );
$top_bar_color = get_post_meta( get_the_ID(), 'top-bar', true );
$top_bar_text = get_post_meta( get_the_ID(), 'top-bar-text', true );
$dynamic_nav_color = get_post_meta( get_the_ID(), 'dynamic-nav', true );
$dynamic_nav_text = get_post_meta( get_the_ID(), 'text-dynamic-nav', true );
$meta_col = get_post_meta( get_the_ID(), 'meta-col', true ); 
$xs = "col-lg-5 col-md-8 col-sm-12"; 
$small = "col-lg-6 col-md-8 col-sm-12"; 
$medium = "col-lg-7 col-md-10 col-sm-12"; 
$large = "col-lg-10 col-md-11 col-sm-12";
$custom_css = get_post_meta( get_the_ID(), 'custom-css', true );
$title = get_post_meta( get_the_ID(), 'webdoc_hometitre', true );
$style = get_post_meta( get_the_ID(), 'webdoc_homestyle', true );
$alignement = get_post_meta( get_the_ID(), 'webdoc_homealignement', true );
$chap = get_post_meta( get_the_ID(), 'chapitre_webdoctitre', true );
$meta_quote = get_post_meta( get_the_ID(), 'quote-design', true );
$meta_quote_design = get_post_meta( get_the_ID(), 'quote', true ); 
$meta_arrow_color = get_post_meta( get_the_ID(), 'meta-arrow-color', true ); 
$image = get_post_meta( get_the_ID(), 'webdoc_homeimage', true );
	
if (!empty($meta_font))
{ ?> <?php if ($meta_font == "select-six")
 { ?> <link href="https://fonts.googleapis.com/css?family=Arvo:400,700" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-seven")
 { ?> <link href="https://fonts.googleapis.com/css?family=DM+Sans:400,700" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-eight")
 { ?> <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-nine")
 { ?> <link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-ten")
 { ?> <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,700" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-eleven")
 { ?> <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-twelve")
 { ?> <link href="https://fonts.googleapis.com/css?family=Ubuntu+Condensed" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-thirteen")
 { ?> <link href="https://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-fourteen")
 { ?> <link href="https://fonts.googleapis.com/css?family=Playfair+Display" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-fifteen")
 { ?> <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-sixteen")
 { ?> <link href="https://fonts.googleapis.com/css?family=Bree+Serif" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-seventeen")
 { ?> <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-heighteen")
 { ?> <link href="https://fonts.googleapis.com/css?family=Oswald:700" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-nineteen")
 { ?> <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-twenty")
 { ?> <link href="https://fonts.googleapis.com/css?family=Lobster+Two" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-twenty-one")
 { ?> <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-twenty-two")
 { ?> <link href="https://fonts.googleapis.com/css?family=Montserrat+Alternates" rel="stylesheet"><?php
 }
 else if ($meta_font == "select-twenty-three")
 { ?> <link href="https://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet"><?php
 }
 else if ($meta_font == "belleza")
 { ?> <link href="https://fonts.googleapis.com/css?family=Belleza:400,700" rel="stylesheet"><?php
 }
  else if ($meta_font == "poppins")
 { ?> <link href="https://fonts.googleapis.com/css?family=Poppins:400,700" rel="stylesheet"><?php
 }
  else if ($meta_font == "archivo")
 { ?> <link href="https://fonts.googleapis.com/css?family=Archivo:400,700" rel="stylesheet"><?php
 }
  else if ($meta_font == "epilogue")
 { ?> <link href="https://fonts.googleapis.com/css?family=Epilogue:400,700" rel="stylesheet"><?php
 }
  else if ($meta_font == "nunito")
 { ?> <link href="https://fonts.googleapis.com/css?family=Nunito:400,700" rel="stylesheet"><?php
 }
  else if ($meta_font == "sora")
 { ?> <link href="https://fonts.googleapis.com/css?family=Sora:400,700" rel="stylesheet"><?php
 }
  else if ($meta_font == "source")
 { ?> <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700" rel="stylesheet"><?php
 }
  else if ($meta_font == "lora")
 { ?> <link href="https://fonts.googleapis.com/css?family=Lora:400,700" rel="stylesheet"><?php
 }
}

if (!empty($meta_font_title) && $meta_font != $meta_font_title)
{ ?> <?php if ($meta_font_title == "select-one")
 { ?> <link href="https://fonts.googleapis.com/css?family=DM+Sans:400,700" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-two")
 { ?> <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-three")
 { ?> <link href="https://fonts.googleapis.com/css?family=Arvo:400,700" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-four")
 { ?> <link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-five")
 { ?> <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,700" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-six")
 { ?> <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-seven")
 { ?> <link href="https://fonts.googleapis.com/css?family=Ubuntu+Condensed" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-eight")
 { ?> <link href="https://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-nine")
 { ?> <link href="https://fonts.googleapis.com/css?family=Playfair+Display" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-ten")
 { ?> <link href="https://fonts.googleapis.com/css?family=Raleway:600" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-eleven")
 { ?> <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-twelve")
 { ?> <link href="https://fonts.googleapis.com/css?family=Bree+Serif" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-thirteen")
 { ?> <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-fourteen")
 { ?> <link href="https://fonts.googleapis.com/css?family=Oswald:700" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-fifteen")
 { ?> <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-sixteen")
 { ?> <link href="https://fonts.googleapis.com/css?family=Lobster+Two" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-seventeen")
 { ?> <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "select-heighteen")
 { ?> <link href="https://fonts.googleapis.com/css?family=Montserrat+Alternates" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "belleza")
 { ?> <link href="https://fonts.googleapis.com/css?family=Belleza:400,700" rel="stylesheet"><?php
 }
 else if ($meta_font_title == "poppins")
 { ?> <link href="https://fonts.googleapis.com/css?family=Poppins:400,700" rel="stylesheet"><?php
 }
  else if ($meta_font_title == "archivo")
 { ?> <link href="https://fonts.googleapis.com/css?family=Archivo:400,700" rel="stylesheet"><?php
 }
  else if ($meta_font_title == "epilogue")
 { ?> <link href="https://fonts.googleapis.com/css?family=Epilogue:400,700" rel="stylesheet"><?php
 }
  else if ($meta_font_title == "nunito")
 { ?> <link href="https://fonts.googleapis.com/css?family=Nunito:400,700" rel="stylesheet"><?php
 }
  else if ($meta_font_title == "sora")
 { ?> <link href="https://fonts.googleapis.com/css?family=Sora:400,700" rel="stylesheet"><?php
 }
  else if ($meta_font_title == "source")
 { ?> <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700" rel="stylesheet"><?php
 }
  else if ($meta_font_title == "lora")
 { ?> <link href="https://fonts.googleapis.com/css?family=Lora:400,700" rel="stylesheet"><?php
 }
 
} ?> 


<style type="text/css"><?php if (!empty($body_color))

if (!empty($meta_font))
{
 if ($meta_font == "select-one")
 { ?> html,body{font-family:Arial,Helvetica,sans-serif}<?php
 }
 else if ($meta_font == "select-two")
 { ?> html,body{font-family:Georgia,serif;font-size:1.1em}.section_title{font-size:3.8em}<?php
 }
 else if ($meta_font == "select-three")
 { ?> html,body{font-family:Tahoma,Geneva,sans-serif}<?php
 }
 else if ($meta_font == "select-four")
 { ?> html,body{font-family:"Times New Roman",Times,serif;font-size:1.1em}.section_title{font-size:3.8em}<?php
 }
 else if ($meta_font == "select-five")
 { ?> html,body{font-family:Verdana,Geneva,sans-serif}<?php
 }
 else if ($meta_font == "select-six")
 { ?> html,body{font-family:'Arvo',serif}<?php
 }
 else if ($meta_font == "select-seven")
 { ?> html,body{font-family:'DM Sans',sans-serif}<?php
 }
 else if ($meta_font == "select-eight")
 { ?> html,body{font-family:'Open Sans',sans-serif}<?php
 }
 else if ($meta_font == "select-nine")
 { ?> html,body{font-family:'Roboto',sans-serif}<?php
 }
 else if ($meta_font == "select-ten")
 { ?> html,body{font-family:'Roboto Slab',serif}<?php
 }
 else if ($meta_font == "select-eleven")
 { ?> html,body{font-family:'Lato',sans-serif}<?php
 }
 else if ($meta_font == "select-twelve")
 { ?> html,body{font-family:'Ubuntu Condensed',sans-serif}<?php
 }
 else if ($meta_font == "select-thirteen")
 { ?> html,body{font-family:'Inconsolata',cursive}<?php
 }
 else if ($meta_font == "select-fourteen")
 { ?> html,body{font-family:'Playfair Display',serif}<?php
 }
 else if ($meta_font == "select-fifteen")
 { ?> html,body{font-family:'Roboto',sans-serif;font-weight:300}<?php
 }
 else if ($meta_font == "select-sixteen")
 { ?> html,body{font-family:'Bree Serif',serif}<?php
 }
 else if ($meta_font == "select-seventeen")
 { ?> html,body{font-family:'Oswald',sans-serif}<?php
 }
 else if ($meta_font == "select-heighteen")
 { ?> html,body{font-family:'Oswald',sans-serif;font-weight:700}<?php
 }
 else if ($meta_font == "select-nineteen")
 { ?> html,body{font-family:'Lobster',cursive}<?php
 }
 else if ($meta_font == "select-twenty")
 { ?> html,body{font-family:'Lobster Two',cursive}<?php
 }
 else if ($meta_font == "select-twenty-one")
 { ?> html,body{font-family:'Montserrat',sans-serif}<?php
 }
 else if ($meta_font == "select-twenty-two")
 { ?> html,body{font-family:'Montserrat Alternates',sans-serif}<?php
 }
 else if ($meta_font == "select-twenty-three")
 { ?> html,body{font-family:'Raleway',sans-serif}<?php
 }
  else if ($meta_font == "belleza")
 { ?> html,body{font-family:'Belleza',serif}<?php
 }
  else if ($meta_font == "poppins")
 { ?> html,body{font-family:'Poppins',sans-serif}<?php
 }
  else if ($meta_font == "archivo")
 { ?> html,body{font-family:'Archivo',sans-serif}<?php
 }
 else if ($meta_font == "epilogue")
 { ?> html,body{font-family:'Epilogue',sans-serif}<?php
 }
 else if ($meta_font == "nunito")
 { ?> html,body{font-family:'Nunito',sans-serif}<?php
 }
  else if ($meta_font == "sora")
 { ?> html,body{font-family:'Sora',sans-serif}<?php
 }
   else if ($meta_font == "source")
 { ?> html,body{font-family:'Source Sans Pro',sans-serif}<?php
 }
   else if ($meta_font == "lora")
 { ?> html,body{font-family:'Lora',serif}<?php
 }
}

if (!empty($meta_font_size))
{
 if ($meta_font_size == "select-two")
 { ?> #section2{font-size:1.25em}<?php
 }
 elseif ($meta_font_size == "select-three")
 { ?> #section2{font-size:.1.1em}.content{font-size:1.1em!important}<?php
 }
 else
 { ?> #section2{font-size:1.15em}<?php
 }
}


/*Titles*/
if (!empty($meta_font_title))
{
 if ($meta_font_title == "select-one")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'DM Sans',sans-serif}<?php
 }
 else if ($meta_font_title == "select-two")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Open Sans',sans-serif}<?php
 }
 else if ($meta_font_title == "select-three")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Arvo',serif}<?php
 }
 else if ($meta_font_title == "select-four")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Roboto',sans-serif}<?php
 }
 else if ($meta_font_title == "select-five")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Roboto Slab',serif}<?php
 }
 else if ($meta_font_title == "select-six")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Lato',sans-serif}<?php
 }
 else if ($meta_font_title == "select-seven")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Ubuntu Condensed',sans-serif}<?php
 }
 else if ($meta_font_title == "select-eight")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Inconsolata',cursive}<?php
 }
 else if ($meta_font_title == "select-nine")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Playfair Display',serif}<?php
 }
 else if ($meta_font_title == "select-ten")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Raleway',sans-serif}<?php
 }
 else if ($meta_font_title == "select-eleven")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Roboto',sans-serif;font-weight:300}<?php
 }
 else if ($meta_font_title == "select-twelve")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Bree Serif',serif}<?php
 }
 else if ($meta_font_title == "select-thirteen")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Oswald',sans-serif}<?php
 }
 else if ($meta_font_title == "select-fourteen")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Oswald',sans-serif;font-weight:700}<?php
 }
 else if ($meta_font_title == "select-fifteen")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Lobster',cursive}<?php
 }
 else if ($meta_font_title == "select-sixteen")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Lobster Two',cursive}<?php
 }
 else if ($meta_font_title == "select-seventeen")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Montserrat',sans-serif}<?php
 }
 else if ($meta_font_title == "select-eighteen")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Montserrat Alternates',sans-serif}<?php
 }
 else if ($meta_font_title == "belleza")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Belleza',serif}<?php
 }
 else if ($meta_font_title == "poppins")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Poppins',sans-serif}<?php
 }
 else if ($meta_font_title == "poppins")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Archivo',sans-serif}<?php
 }
 else if ($meta_font_title == "poppins")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Epilogue',sans-serif}<?php
 }
 else if ($meta_font_title == "nunito")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Nunito',sans-serif}<?php
 }
  else if ($meta_font_title == "sora")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Sora',sans-serif}<?php
 }
  else if ($meta_font_title == "source")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Source Sans Pro',sans-serif}<?php
 }
  else if ($meta_font_title == "lora")
 { ?> #menuleft h3, #intranav h3, .navbar-brand, #section1 h1, #section2 h1, #section2 h2, #section2 h3, #section2 h4, #section2 h5, #section3 h3{font-family:'Lora',serif}<?php
 }
} ?>
	body{background:<?php echo $body_color; ?>;}
	#section1{background: <?php echo $meta_color; ?> url('<?php echo $image; ?>') center center no-repeat;-webkit-background-size: cover!important;-moz-background-size: cover!important;-o-background-size: cover!important; background-size:cover;} 
	#section2, #section2 p,#section2 a:hover{color:<?php echo $meta_text_color; ?>;}
	footer{background:<?php echo $footer_color; ?>;color:<?php echo $text_footer_color; ?>;}
	footer a,footer a:hover{color:<?php echo $text_footer_color; ?>;}
	#menu,#menunav{background:<?php echo $top_bar_color; ?>;color:<?php echo $top_bar_text; ?>;}
	#menu a,#menu a:hover,#menunav a,#menunav a:hover{color:<?php echo $top_bar_text; ?>;text-decoration:none;}
	#section2 a{color:<?php echo $meta_color; ?>}
	#intranav,#menuleft{background:<?php echo $dynamic_nav_color; ?>;color:<?php echo $dynamic_nav_text; ?>;}
	#intranav a,#menuleft a{color:<?php echo $dynamic_nav_text; ?>;}
	#section3 a{color:<?php echo $meta_text_color; ?>;}
	#section3 a:hover,#intranav h3 a:hover{color:<?php echo $meta_color; ?>!important;}
	#section3 h4,#intranav h4{color:<?php echo $meta_color; ?>;}
	#navspan,.panel{border:1px solid <?php echo $meta_color; ?>;}
	.panel{color:<?php echo $meta_color; ?>;}
	.jumbotron,.btn-slf{background:<?php echo $top_bar_color; ?>;color:<?php echo $top_bar_text; ?>;}
	.btn-slf a{color:<?php echo $top_bar_text; ?>;}
	.mejs-controls .mejs-time-rail .mejs-time-total,.mejs-currenttime,.mejs-duration{background:color:<?php echo $top_bar_text; ?>!important;}
	.mejs-horizontal-volume-current, .mejs-controls .mejs-time-rail .mejs-time-current{background: <?php echo $meta_color; ?>!important;}
	<?php if ( $style != "option-one" ) : ?>#section1 h1 span{background: <?php echo $meta_color; ?>;padding:10px 20px 15px 20px;display:inline-block;} <?php endif; ?>
	<?php
		if( !empty( $meta_quote) ) {
			if ($meta_quote == "select-one") { ?> blockquote{border:0;border-left:4px solid;padding-left:20px;margin-left:40px;}<?php } 
			elseif ($meta_quote == "select-two") { ?> blockquote{border:0;border-right:4px solid;padding-right:20px;margin-right:40px;}<?php }  
			elseif ($meta_quote == "select-three") { ?> blockquote{border:0;border:none!important!;} blockquote::before {content:"\201C";display: inline;height: 0; line-height: 0;position: relative;top: 10px!important;color:<?php echo $meta_color; ?>;
			font-size: 4em;font-family: 'Times New Roman',serif;left:45%} blockquote::after {content:"\201D";left:45%;display: inline;height: 0; line-height: 0;position: relative;top: 35px;color:<?php echo $meta_color; ?>;font-size: 4em;font-family: 'Times New Roman',serif;} 	@media only screen and (max-width: 767px) { blockquote{font-size: 1.15em;font-family:'Raleway',sans-serif;} blockquote::before {top: 20px} 		blockquote::after {top:30px;} 	}<?php }
		}
		if ( $meta_quote_design == 'select-one' ) { ?> blockquote{border-color:<?php echo $meta_color; ?>}<?php } 
		elseif ( $meta_quote_design == 'select-two' ) { ?> blockquote{border-color:<?php echo $meta_color; ?>;border-style:dotted}<?php } 
		elseif ( $meta_quote_design == 'select-four' ) { ?> blockquote{border-style:dotted}<?php } else { ?> blockquote{border-color:#eee}<?php } 
		if ( is_user_logged_in() ) : ?>
		#menu,#menunav{top:32px;}
	<?php 
		endif;
		if ( $alignement == "option-one" ) : ?>#section1 h1{text-align:left;} <?php endif; 
		if ( $alignement == "option-two" ) : ?>#section1 h1{text-align:center;} <?php endif;
		if ( $alignement == "option-three" ) : ?>#section1 h1{text-align:right;} <?php endif; 
		if (!empty($meta_arrow_color) ) : ?>#more a{color:<?php echo $meta_arrow_color; ?>!important;}<?php else :?>#more a{color:#FFFFFF;}<?php endif;
		echo $custom_css; 
	?>
</style>
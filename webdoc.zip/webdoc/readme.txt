﻿=== Plugin Name ===
Contributors: Laurence(at)OhMyBox.info
Donate link: http://journodev.com
Tags: webdoc, stories, webdoc, custom post, journalist tool, longreads, journalism, storytelling
Requires at least: 4.2.3
Tested up to: 5.9
Stable tag: 5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Webdocumentary made easy.

== Description ==
Read more: https://journodev.tech/plugin-webdoc/
Documentation available through the "Documentation" menu of the plugin.
Use: Bootstrap 5, Slick.js, Ionicons, Google Fonts

== Installation ==
Dowlaod the zip folder through the dashboard's plugin menu.


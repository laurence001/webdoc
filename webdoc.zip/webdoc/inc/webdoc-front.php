<?php

//Templates calling

	function template_webdoc($template)
	{
		global $wp_query;
		$post_type = get_query_var('post_type');
		$meta_theme = get_post_meta( get_the_ID(), 'meta-theme', true );
			if($post_type == 'webdoc' )
			{							
				$template = plugin_dir_path( __FILE__ ) . '../templates/single-webdoc.php';
			}
		return $template;
	}
	
	add_filter('template_include', 'template_webdoc');
	
	
	function webdoc_archive_template( $template ) {
	 
	 $post_type = get_query_var('post_type');
		
		if ( $post_type == 'webdoc' && is_post_type_archive('webdoc') ) {
			$template = plugin_dir_path( __FILE__ ) . '../templates/archives-webdoc.php';
		}
	  
	  return $template;

	 }
	
	add_filter('template_include', 'webdoc_archive_template');
	
//Date archive

	add_action('generate_rewrite_rules', 'webdoc_archives_rewrite_rules');
		function webdoc_archives_rewrite_rules($wp_rewrite) {
		  $rules = webdoc_date_archives('webdoc', $wp_rewrite);
		  $wp_rewrite->rules = $rules + $wp_rewrite->rules;
		  return $wp_rewrite;
		}

	function webdoc_date_archives($cpt, $wp_rewrite) {
	  $rules = array();
	 
	  $post_type = get_post_type_object($cpt);
	  $slug_archive = $post_type->has_archive;
	  if ($slug_archive === false) return $rules;
	  if ($slug_archive === true) {
		$slug_archive = isset($post_type->rewrite['slug']) ? $post_type->rewrite['slug'] : $post_type->name;
	}
 
  $dates = array(
    array(
      'rule' => "([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})",
      'vars' => array('year', 'monthnum', 'day')),
    array(
      'rule' => "([0-9]{4})/([0-9]{1,2})",
      'vars' => array('year', 'monthnum')),
    array(
      'rule' => "([0-9]{4})",
      'vars' => array('year'))
  );
 
  foreach ($dates as $data) {
    $query = 'index.php?post_type='.$cpt;
    $rule = $slug_archive.'/'.$data['rule'];
 
    $i = 1;
    foreach ($data['vars'] as $var) {
      $query.= '&'.$var.'='.$wp_rewrite->preg_index($i);
      $i++;
    }
 
    $rules[$rule."/?$"] = $query;
    $rules[$rule."/feed/(feed|rdf|rss|rss2|atom)/?$"] = $query."&feed=".$wp_rewrite->preg_index($i);
    $rules[$rule."/(feed|rdf|rss|rss2|atom)/?$"] = $query."&feed=".$wp_rewrite->preg_index($i);
    $rules[$rule."/page/([0-9]{1,})/?$"] = $query."&paged=".$wp_rewrite->preg_index($i);
  }
 
  return $rules;
}

function webdoc_remove_block_library_css(){
    wp_dequeue_style( 'wp-block-library' );
} 
add_action( 'wp_enqueue_scripts', 'webdoc_remove_block_library_css' );

//Deregister styles and scripts
function unhook_theme_style_webdoc() {
	global $wp_query;
	$post_type = get_query_var('post_type');
	if ( $post_type == 'webdoc' ) {
		wp_dequeue_style( 'style' );
		wp_deregister_style( 'style' );
		wp_register_style( 'style', false );
		wp_dequeue_style( 'print' );
		wp_deregister_style( 'print' );
		wp_dequeue_style( 'normalize' );
		wp_deregister_style( 'normalize' );
		wp_dequeue_style( 'bootstrap' );
		wp_deregister_style( 'bootstrap' );
		wp_dequeue_style( 'font-awesome' );
		wp_deregister_style( 'font-awesome' );
		wp_dequeue_style( 'wp-block-library-css' );
		wp_deregister_style( 'wp-block-library-css' );
		wp_dequeue_style( 'genericons' );
		wp_deregister_style( 'genericons' );
		wp_dequeue_style( 'twentysixteen-style' );
		wp_deregister_style( 'twentysixteen-style' );
		wp_dequeue_style( 'weta-style-css' );
		wp_deregister_style( 'weta-style-css' );
		wp_dequeue_script( 'mainscript' );
		wp_deregister_script( 'mainscript' );
		wp_deregister_script( 'main' );
		wp_dequeue_script( 'main' );
		wp_dequeue_script( 'bootstrapmin' );
		wp_deregister_script( 'bootstrapmin' );
		wp_dequeue_script( 'weta-script' );
		wp_deregister_script( 'weta-script' );
		wp_dequeue_script( 'weta-flex-slider-style' );
		wp_deregister_script( 'weta-flex-slider-style' );
		wp_dequeue_script( 'menu' );
		wp_deregister_script( 'menu' );
		wp_dequeue_script( 'custom' );
		wp_deregister_script( 'custom' );
		wp_dequeue_script( 'custom.min' );
		wp_deregister_script( 'custom.min' );
		wp_dequeue_style( 'wp-block-library-css' );
		wp_deregister_style( 'wp-block-library-css' );
		wp_dequeue_style( 'wp-block-library-theme-css' );
		wp_deregister_style( 'wp-block-library-theme-css' );
			remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
			remove_action( 'admin_enqueue_scripts', 'print_emoji_detection_script' );
			remove_action( 'wp_print_styles', 'print_emoji_styles' );
			remove_action( 'wp_print_styles', 'wp-block-library-css' );
			remove_action( 'admin_print_styles', 'print_emoji_styles' ); 
		wp_enqueue_script ('jquery');
		wp_register_style( 'bootstrap', plugin_dir_url( __FILE__ ) . '../css/bootstrap.min.css');
		wp_enqueue_style( 'bootstrap');
		wp_register_style( 'ionicons', plugin_dir_url( __FILE__ ) . '../fonts/ionicons/css/ionicons.min.css');
		wp_enqueue_style( 'ionicons');
		wp_register_script('bootstrap-js', plugin_dir_url( __FILE__ ) . '../js/bootstrap.min.js',array('jquery'),null,true);
		wp_enqueue_script ('bootstrap-js');
	}
	if ( $post_type == 'webdoc' && !is_archive('webdoc' ) ) {
		wp_register_style( 'slick',  plugin_dir_url( __FILE__ ) . '../css/slick.css' );
		wp_enqueue_style( 'slick' );
		wp_register_style( 'webdoc-styles',  plugin_dir_url( __FILE__ ) . '../css/style.css' );
		wp_enqueue_style( 'webdoc-styles' );
		wp_register_script('slick', plugin_dir_url( __FILE__ ) . '../js/slick.min.js',array('jquery'),null,true);
		wp_enqueue_script ('slick');
		wp_register_script('webdoc-js', plugin_dir_url( __FILE__ ) . '../js/webdoc.js',array('jquery'),null,true);
		wp_enqueue_script ('webdoc-js');
			if ( comments_open() ) {
				wp_register_script('comments', plugin_dir_url( __FILE__ ) . '../js/comments.js',array('jquery'),null,true);
				wp_enqueue_script ('comments');	
			}
	}
	if ( !is_category() && !is_tag() && is_post_type_archive('webdoc') ) {
		wp_dequeue_script( 'infinite_scroll' );
		wp_deregister_script( 'infinite_scroll' );
		wp_dequeue_script( 'scroll' );
		wp_deregister_script( 'scroll' );
		wp_register_style( 'effekt-css', plugin_dir_url( __FILE__ ) . '../css/effekt.css');
		wp_enqueue_style( 'effekt-css');
		wp_register_script('scroll-js', plugin_dir_url( __FILE__ ) . '../js/scroll.js',array('jquery'),null,true);
		wp_enqueue_script ('scroll-js');
		wp_register_script('scroller-js', plugin_dir_url( __FILE__ ) . '../js/scroller.js',array('jquery'),null,true);
		wp_enqueue_script ('scroller-js');
		wp_register_style( 'archive-css', plugin_dir_url( __FILE__ ) . '../css/archive.css');
		wp_enqueue_style( 'archive-css');
	}
}
add_action( 'wp_enqueue_scripts', 'unhook_theme_style_webdoc', 9999 );

function is_post_type($type){
    global $wp_query;
    if($type == get_post_type($wp_query->post->ID)) 
        return true;
    return false;
}

function webdoc_the_page_siblings(){
    $post_id = get_the_ID();
    $parent_id = wp_get_post_parent_id($post_id);
    $post_type = get_post_type($post_id);

    $sibling_list = get_pages(array(
         'sort_column'=>'menu_order',
         'sort_order' =>'asc',
         'child_of' =>$parent_id,
         'post_type'=> $post_type
    ));

    if( !$sibling_list || is_wp_error($sibling_list) )
        return false;

    $pages = array();
    foreach ($sibling_list as $sibling ) {
         $pages[] = $sibling->ID;
     }

    $current = array_search($post_id, $pages);
    $prevID = isset($pages[$current-1]) ? $pages[$current-1] : false;
    $nextID = isset($pages[$current+1]) ? $pages[$current+1] : false;

    echo webdoc_display_prev_next($prevID, $nextID);
 }
 
  function webdoc_display_prev_next($prevID=false, $nextID=false){
    if( empty($prevID) && empty($nextID) )
       return false;

    $html = '<div class="navigation">';

    if( !empty($nextID) ){
         $html .= '<span id="navspan"> <img src=' . get_the_post_thumbnail_url($nextID). '>';
         $html .= '<a href="'.get_permalink($nextID).'">' . get_the_title($nextID) . ' <span class="ion ion-arrow-right-b"><span> </a>';
         $html .= '</span>';
     }

    $html .= '</div><!-- .navigation -->';

    return $html;
}

	
add_image_size( 'webdoc', 600, 400, array( 'center', 'center' ) ); 
?>
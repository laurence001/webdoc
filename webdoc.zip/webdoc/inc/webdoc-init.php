<?php

//Create post type webdoc

function webdoc_create_post_type() {

  register_post_type( 'webdoc',
    array(
      'labels' => array(
        'name' => __( 'Webdocs'),
        'singular_name' => __( 'Webdoc', 'webdoc' ),
		'add_new' => __( 'Créer', 'webdoc' ),
        'add_new_item' => __( 'Ajouter un webdoc', 'webdoc' ),
        'edit_item' => __( 'Editer le webdoc', 'webdoc' ),
        'new_item' => __( 'Nouveau webdoc', 'webdoc' ),
        'view_item' => __( 'Voir le webdoc', 'webdoc' ),
        'search_items' => __( 'Rechercher un webdoc', 'webdoc' ),
        'not_found' => __( 'Aucun webdoc trouvé', 'webdoc' ),
        'not_found_in_trash' => __( 'Aucun webdoc dans la corbeille', 'webdoc' ),
        'parent_item_colon' => __( 'webdoc (parent) :', 'webdoc' )

      ),

			'public'              	=> true,
			'publicly_queryable'  	=> true,
			'exclude_from_search' 	=> false,
			'show_ui'             	=> true,
			'show_in_menu'        	=> true,
			'menu_position'       	=> 20,
			'menu_icon'				=> 'dashicons-welcome-view-site',
			'capability_type'     	=> 'post',
			'hierarchical'        	=> true,
			'supports'            	=> array( 'title', 'revisions', 'editor', 'author', 'excerpt', 'thumbnail','page-attributes'),
			'taxonomies' 			=> array('post_tag','category'),
			'has_archive'         	=> false,
			'rewrite' 				=> array('slug' => 'webdoc', 'with_front' => true),
			'query_var'           	=> true,
			'can_export'          	=> true

    )

  );

}
add_action( 'init', 'webdoc_create_post_type' );


//Flush

register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
register_activation_hook( __FILE__, 'webdoc_flush_rewrites' );

function webdoc_flush_rewrites() {

	webdoc_create_post_type();
	flush_rewrite_rules();

}
add_action( 'after_switch_theme', 'flush_rewrite_rules' );

//Preview (debug)

add_filter('_wp_post_revision_fields', 'add_webdoc_debug_preview');
function add_webdoc_debug_preview($fields){
   $fields["debug_preview"] = "debug_preview";
   return $fields;
}

add_action( 'edit_form_after_title', 'webdoc_input_debug_preview' );
function webdoc_input_debug_preview() {
   echo '<input type="hidden" name="debug_preview" value="debug_preview">';
}

function webdoc_dashboard_css() {
		echo '<link rel="stylesheet" type="text/css" href="'. plugin_dir_url( __FILE__ ) .'css/webdoc-dash.css"/>';
	}
	add_action('admin_head', 'webdoc_dashboard_css', 1);
	
?>
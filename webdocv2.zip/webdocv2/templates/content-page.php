<nav id="menunav">
	<div id="open" class="resp">
		<span class="ion ion-navicon-round"></span>
	</div>
			
	<div id="closed" style="display: none;" class="resp">
		<span class="ion ion-close"></span>
	</div>
	
	<div id="openi" class="noresp">
		<span class="ion ion-navicon-round"></span>
	</div>
			
	<div id="closedi" style="display: none;" class="noresp">
		<span class="ion ion-close"></span>
	</div>
	
	<div class="navbar-brand"><a href="<?php $page_id = wp_get_post_parent_id(); echo get_permalink( $page_id ); ?>"><?php $page_id = wp_get_post_parent_id(); echo get_the_title( $page_id ); ?></a></div>
	
	<div class="container">
			<div id="float-right">
				<ul>
				<li>
					<a target="_blank" href="https://twitter.com/intent/tweet?url=<?php  the_permalink(); ?>&text=<?php the_title(); ?>">			
					<span class="ion ion-social-twitter"></span>
					</a>
				</li>
				<li>				
					<a href="http://www.facebook.com/sharer.php?u=<?php  the_permalink(); ?>&t=<?php the_title(); ?>" target="blank">
					<span class="ion ion-social-facebook"></span>
					</a>
				</li>
				</ul>
			</div>
		</div>
</nav>

<div id="menuleft" class="menuhome">
	
	<h3><a href="<?php $page_id = wp_get_post_parent_id(); echo get_permalink( $page_id ); ?>"><?php $page_id = wp_get_post_parent_id(); echo get_the_title( $page_id ); ?></a></h3>
	<ul class="navbar-nav mr-auto float-left">
	<li class="nav-item">
	<?php 
		$titre = get_the_title();
		$args = array(
			'post_parent' => $page_id,
			'post_type' => 'webdoc',
			'orderby' => 'menu_order',
			'order' => 'ASC'
		);

		$child_query = new WP_Query( $args );
		 while ( $child_query->have_posts() ) : $child_query->the_post(); 
			$thisid = get_the_title();  ?>
			<a class="nav-link <?php if ($titre == $thisid): echo 'active'; endif; ?>" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		<?php 
			endwhile;
			wp_reset_postdata();
		?>
		</li>
	</ul>
</div>

	<header id="section1">
		<div class="container">
			
			<div id="content1">
				<div id="table">
					<div id="table-cell">
						<div id="main-title" class="main-page">
							<?php if (empty($title) ) : ?>
							<h1><span><?php the_title(); ?></span></h1>	  
							<?php endif; ?>
						</div>
					</div>
				</div>
			
			</div>
		</div>
		<div id="more">
			<?php $arrow = get_post_meta(get_the_ID() , 'arrow', true); ?>	
			<a href="#section2" class="scrollTo">
			<?php if ($arrow == "select-one") { ?>
			<span class="ion ion-chevron-down"></span>
			<?php } elseif ($arrow == "select-two") { ?>
			<span class="ion ion-arrow-down-b"></span>
			<?php } elseif ($arrow == "select-three") { ?>
			<span class="ion ion-arrow-down-c"></span>
			<?php } elseif ($arrow == "select-four") { ?>
			<span class="ion ion-ios-arrow-down"></span>
			<?php } elseif ($arrow == "select-five") { ?>
			<span class="ion ion-ios-arrow-thin-down"></span>
			<?php } elseif ($arrow == "select-six") { ?>
			<span class="ion ion-android-arrow-dropdown-circle"></span>
			<?php } elseif ($arrow == "select-seven") { ?>
			<span class="ion-android-arrow-down"></span>
			<?php } elseif ($arrow == "select-eight") { ?>
			<span class="ion-ios-download"></span>
			<?php } else { ?>
			<span class="ion ion-ios-download-outline"></span>
			<?php } ?>
			</a>
		</div>
	</header>
	
<div id="intranav">
	<div class="container">
		<div class="row">
		<div class="slick">
			<?php $args = array(
				'post_parent' => $page_id,
				'post_type' => 'webdoc',
				'orderby' => 'menu_order',
				'order' => 'ASC'
			);

			$child_query = new WP_Query( $args );
			$n = 1;
			 while ( $child_query->have_posts() ) : $child_query->the_post(); 
			 $thisidb = get_the_title(); 
			 $thisidc = get_the_title(); ?>

				<div class="col-lg-3 col-md-3 col-sm-12">  
				<?php if ($titre == $thisidb): echo '<div class="active">'; endif; ?>
					<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>">
						<?php  
							if ( has_post_thumbnail() ) {
								the_post_thumbnail('webdoc');
							}
						?>
					</a>
					<h4><?php echo $chap . " " . $n; ?></h4>
					<h3><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
				<?php if ($titre == $thisidc): echo '</div>'; endif; ?>
				
				</div>
			<?php 
			$n = $n + 1;
			endwhile; wp_reset_postdata(); ?>
		</div>
		</div>
	</div>
</div>
	
	<article id="section2">
		<div class="<?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } elseif ($meta_col == "select-four") { echo $xs; } else { echo $medium; } ?> mx-auto">
			
			<?php 
				$title = get_post_meta( get_the_ID(), 'alaune_une', true );
				$chapeau = get_post_meta( get_the_ID(), 'chapeau', true );
			?>
			
			<?php  if ($title == "yes") : ?>
			<h1><?php the_title(); ?></h1>
			<?php  endif; 
			
				if ($chapeau == "yes") : 
					if ( has_excerpt() ) : ?>
						<div id="chapeau">
							  <?php the_excerpt(); ?>
						</div>
					<?php endif ; 
				endif; ?>
				
				<div id="contenu">
					<?php the_content(); ?>
				</div>
				<?php webdoc_the_page_siblings(); ?>
			
		</div>
		
	</article>
	
	<div class="clear"></div>
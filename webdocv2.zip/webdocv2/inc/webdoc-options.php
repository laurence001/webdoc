<?php
function webdoc_add_admin_menu() {
   add_submenu_page( 'edit.php?post_type=webdoc','Webdoc', 'Documentation', 'manage_options', "webdoc-documentation", "webdoc_settings_page", null, 99);
}
add_action( 'admin_menu', 'webdoc_add_admin_menu' );
function webdoc_settings_page() {
	if (!current_user_can('manage_options')) {
		wp_die(__('Vos droits ne sont pas suffisants pour accéder à cette page.', 'webdoc'));
}
?>

<div class="wrap">
	<div id="icon-options-general" class="icon32"></div>
	    <h2><?php _e('Webdoc', 'webdoc') ?></h2>
			<h2 class="nav-tab-wrapper">
			 <a href="#" class="nav-tab navtab1 active1"><?php _e( 'Documentation', 'webdoc' ); ?></a>	 
			 <a href="#" class="nav-tab navtab2 active2"><?php _e( 'Typographies', 'webdoc' ); ?></a> 
			</h2>
		
		<?php echo '<img style="bottom:32px;right:20px;position:fixed;z-index:999999" src="' . plugins_url( '/images/webdoc.jpg', __FILE__ ) . '" alt="Fonts" /> '; ?>							
				
		
		<div id="tab1" class="ui-sortable meta-box-sortables" style="webdoc_display:none;">		
		<br/>			
			<div class="postbox">
				
				
				<div class="inside" style="max-width:80%;">	
					<h3><?php _e('1. Créer un nouveau webdoc et le configurer', 'webdoc'); ?></h3>	
				
					<p style="font-size:1.2em!important;"><?php _e('Si les réglages ne s\'affichent pas, aller dans "Options d\'écran" pour sélectionner la boîte d\'option.','webdoc') ?></p>
					<p style="font-size:1.2em!important;"><?php _e('Procéder aux réglages du design du webdoc, enregistrer en brouillon et prévisualiser pour vérifier la mise en page.','webdoc') ?></p>
					<p style="font-size:1.2em!important;"><?php _e('Puisque la page d\'accueil du webdoc comporte un slider avec les vignettes de chaque section du webdoc, il est conseillé de régler la largeur de la colonne sur "large".','webdoc') ?></p>
					<p style="font-size:1.2em!important;"><?php _e('Vous pouvez ajoute une catégorie de WordPress ainsi que des mots-clés (étiquettes).','webdoc') ?></p>
					<p style="font-size:1.2em!important;"><?php _e('La zone "En-tête" permet d\'ajouter la photo de couverture et de régler l\'apparence du titre.','webdoc') ?></p>
					<p style="font-size:1.2em!important;"><?php _e('La zone "Chapitre" contient l\'étiquette de votre navigation (cela peut être "Chapitre", "Episode", "Section", "Partie", etc.).','webdoc') ?></p>
					<p style="font-size:1.2em!important;"><?php _e('Lorsque votre mise en page est terminée, enregistrer la page.", "Episode", "Section", "Partie", etc.).','webdoc') ?></p>
				
				
				<?php _e('<img style="width:100%;max-width:900px;margin:30px 0;float:none;" src="' . plugins_url( '/images/cap1.jpg', __FILE__ ) . '" alt="screenshot" />','webdoc'); ?>							
					
				
				<h3><?php _e('2. Créer une section du webdoc', 'webdoc'); ?></h3>	
				
				<p style="font-size:1.2em!important;"><?php _e('Pour ne pas répéter toutes les actions de configuration du design, survoler le titre de la première page du webdoc et cliquer sur "Duplicate". Un article du même titre apparaît en brouillon, il faut ensuite l\'éditer.','webdoc') ?></p>
				
				<?php _e('<img style="width:100%;max-width:900px;margin:30px 0;float:none;" src="' . plugins_url( '/images/cap2.jpg', __FILE__ ) . '" alt="screenshot" />','webdoc'); ?>	
				
				<p style="font-size:1.2em!important;"><?php _e('Ici, il est conseillé de modifier la largeur du contenu de la page (ex. colonne de largeur "Small"), de manière à faciliter la lecture du texte.','webdoc') ?></p>
				<p style="font-size:1.2em!important;"><?php _e('Lorsque les réglages d\'une page intérieure sont terminés, il est conseillé de la dupliquer de manière à harmoniser les sections suivantes.','webdoc') ?></p>
				<p style="font-size:1.2em!important;"><?php _e('Attention: ne pas attribuer de catégorie et de mot-clés à une page intérieure.','webdoc') ?></p>
				<p style="font-size:1.2em!important;"><?php _e('Attention: s\'assurer que la zone "Chapitre" est identique à celle de la première page du webdoc.','webdoc') ?></p>
				<p style="font-size:1.2em!important;"><?php _e('Pour lier la sous-page à la page principale du webdoc, sélectionner le titre dans le menu déroulant "Parent" sous "Attributs de la page".','webdoc') ?></p>
				<p style="font-size:1.2em!important;"><?php _e('Le champ "Ordre" permet de définir l\'ordre de défilement du webdoc (la numérotation doit débuter à 1).','webdoc') ?></p>
				<p style="font-size:1.2em!important;"><?php _e('Astuce : il est toujours possible de revoir l\'ordre des pages via la modification rapide de WordPress.','webdoc') ?></p>
				
				<?php _e('<img style="width:100%;max-width:900px;margin:30px 0;float:none;" src="' . plugins_url( '/images/cap3.jpg', __FILE__ ) . '" alt="screenshot" />','webdoc'); ?>							
						
				<p style="font-size:1.2em!important;">
					<?php _e('Le plugin "webdoc" est conçu pour être compatible avec WordPress mais il est possible que des incompabilités puissent être observées avec certains plugins. 					Ce plugin inclut les éléments javascript de Bootstrap 5.1.3 et de la librairie JavaScript Slick.js. 					Un webdoc de base est conçu pour trois ou quatre sous-parties, le slider est activé automatiquement 					dès que le nombre de sous-partie va au-delà de quatre. Il n\'y a aucune limitation dans le nombre de 					sous-parties (ou chapitres). Ce plugin est accessible en français, anglais et néerlandais. <br> Les utilisateurs qui souhaitent soutenir ce plugin peuvent le faire en mentionnant dans les crédit : "Ce webdoc a été réalisé avec le plugin Webdoc pour Wordpress". Lien : https://journodev.tech/plugin-webdoc/','webdoc'); ?>
				</p>
				</div>
			</div>				
		</div>

		<div id="tab2" class="ui-sortable meta-box-sortables" style="webdoc_display:none;">				
			<br/>
			<div class="postbox">
				<div class="inside" style="font-size:1.2em;">
					<?php _e('5 familles typographiques standards et 26 Google Fonts sont disponibles pour customiser les textes et titres de chaque webdoc.','webdoc'); ?>
					<h3><?php _e('Polices standards', 'webdoc'); ?></h3> 
					<?php echo '<img style="width:100%;max-width:900px;margin:0;float:none;" src="' . plugins_url( '/images/fonts.jpg', __FILE__ ) . '" alt="Fonts" /> '; ?>							
					<h3><?php _e('Google Fonts', 'webdoc'); ?></h3> 
					<?php _e('<a href="https://fonts.google.com/" target="_blank">Prévisualiser les typographies en cliquant sur ce lien</a>','webdoc'); ?>
					<p style="font-size:16px;">
					<?php _e('Il est possible d\'ajuster la taille du texte en fonction de la typographie sélectionnée (small, medium,large)','webdoc'); ?>
					</p>
					<p style="font-size:16px;">
						Arvo, serif<br>
						Bellezza, serif<br>
						Bree, serif<br>
						DM Sans, sans-serif<br>
						Epilogue, sans-serif<br>
						Inconsolata, cursive<br>
						Lato, sans-serif<br>
						Lobster Two, cursive<br>
						Lobster, cursive<br>
						Lora, serif<br>
						Montserrat Alternate, sans-serif<br>
						Montserrat, sans-serif<br>
						Nunito, sans-serif<br>
						Open Sans, sans-serif<br>
						Oswal bold, sans-serif<br>
						Oswald regular, sans-serif<br>
						Playfair Display, serif<br>
						Poppins, sans-serif<br>
						Raleway, sans-serif<br>
						Roboto Light, sans-serif<br>
						Roboto Slab, serif<br>
						Roboto Slab,serif<br>
						Roboto, sans-serif<br>
						Sora,sans-serif<br>
						Source Sans Pro, sans-serif<br>
						Ubuntu Condensed, sans-serif					
					</p>
				</div> 
			</div>
		</div>
		
</div>
<?php  }  ?>
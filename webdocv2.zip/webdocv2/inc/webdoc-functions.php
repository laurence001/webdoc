<?php
	
	add_action( 'pre_get_posts', 'add_webdoc_to_queries', 999);
	function add_webdoc_to_queries ( $query ) {
		if ( !is_admin() ) {
		
			if   ( is_category() || is_tag() && $query->is_main_query() ) {
				$query->set( 'post_type', array( 'post', 'nav_menu_item', 'webdoc','longform','database') );
				return $query; 
			}
			
			if( is_author() && $query->is_main_query() ) {
				$query->set( 'post_type', array('post', 'webdoc','longform','database'));
				return $query;
				}
					
			if ( !is_admin() && is_search() && $query->is_main_query() ) {
				$query->set('post_type', array( 'post', 'webdoc', 'nav_menu_item','longform','database','page') );
				return $query;
			}
			
			if ( !is_admin() && is_home() || is_front_page() && $query->is_main_query() ) {
				$query->set('post_type', array( 'post', 'webdoc', 'nav_menu_item','longform','database') );
				return $query;
			}
		}
	}
		
	function webdoc_register_js() {
		global $typenow;
		$plugin_dir_uri = plugin_dir_url( __FILE__ );
			if( is_admin()  ) {
				wp_register_script( 'webdoc-nav', $plugin_dir_uri .  'js/webdoc-nav.js', array( 'jquery' ) );
				wp_enqueue_script('webdoc-nav');
				wp_register_script( 'webdoc-image', $plugin_dir_uri .  'js/webdoc-image.js', array( 'jquery' ) );
				wp_enqueue_script('webdoc-image');
			}
	}
	add_action('init', 'webdoc_register_js');

function webdoc_admin_styles(){
    global $typenow;
	$plugin_dir_uri = plugin_dir_url( __FILE__ );
		if( $typenow == 'webdoc' && is_admin() ) {
			wp_enqueue_style( 'webdoc_meta_box_styles', $plugin_dir_uri . 'css/webdoc-admin.css' );
		}
}
add_action( 'admin_print_styles', 'webdoc_admin_styles' );

//Loading color picker
function webdoc_color_enqueue() {
	wp_enqueue_script( 'wp-color-picker' );
    wp_enqueue_style( 'wp-color-picker' );
}
add_action( 'admin_enqueue_scripts', 'webdoc_color_enqueue' );

function add_author_support_to_posts() {
   add_post_type_support( 'webdoc', 'author' ); 
   add_post_type_support( 'webdoc', 'editor' ); 
}
add_action( 'init', 'add_author_support_to_posts' );
?>
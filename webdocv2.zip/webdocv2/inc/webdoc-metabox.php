<?php
/**
 *Add METABOXES*
/**

/**Metaboxes contents**/

add_action("add_meta_boxes", "add_webdoc_meta_box");
function add_webdoc_meta_box() {
    add_meta_box('webdoc-meta-box', __('Réglages','webdoc'), 'webdoc_meta_callback', 'webdoc', 'side', 'high', null);
}
function webdoc_custom_meta() {
    add_meta_box( 'webdoc_meta', __( 'Configuration', 'webdoc' ), 'webdoc_meta_callback', 'webdoc' );
}
function webdoc_meta_callback( $post ) {
    wp_nonce_field( basename( __FILE__ ), 'webdoc_nonce' );
    $webdoc_stored_meta = get_post_meta( $post->ID );
?>
<div id="wrap">
<h4 class="nav-tab-wrapper">	 
<a href="#" class="nav-tab navtab1 active1"> <?php _e( 'Général', 'webdoc' ); ?> </a>	 
<a href="#" class="nav-tab navtab2 active2"> <?php _e( 'Contenu', 'webdoc' ); ?> </a> 
</h4> 
<div id="tab1" class="ui-sortable meta-box-sortables">	
	<p>		
		<label for="meta-color" class="webdoc-color"><?php _e( 'Couleur du thème', 'webdoc' )?></label>		
		<br/>		
		<input name="meta-color" class="meta-color" type="text" value="<?php if ( isset ( $webdoc_stored_meta['meta-color'] ) ) { echo $webdoc_stored_meta['meta-color'][0]; } else { ?>#1a456d<?php } ?>" class="meta-color" />	
	</p>
	<p>		
		<label for="meta-text-color" class="webdoc-color"><?php _e( 'Couleur du texte', 'webdoc' )?></label>		
		<br/>		
		<input name="meta-text-color" class="meta-color" type="text" value="<?php if ( isset ( $webdoc_stored_meta['meta-text-color'] ) ) { echo $webdoc_stored_meta['meta-text-color'][0]; } else { ?>#383838<?php } ?>" class="meta-text-color" />	
	</p>
	<p>		
		<label for="body-color" class="webdoc-color"><?php _e( 'Couleur d\'arrière-plan de la page', 'webdoc' )?></label>		
		<br/>		
		<input name="body-color" class="meta-color" type="text" value="<?php if ( isset ( $webdoc_stored_meta['body-color'] ) ) { echo $webdoc_stored_meta['body-color'][0]; } else { ?>#ffffff<?php } ?>" class="body-color" />	
	</p>
	<p>		
		<label for="footer-color" class="webdoc-color"><?php _e( 'Couleur d\'arrière-plan du pied de page', 'webdoc' )?></label>		
		<br/>		
		<input name="footer-color" class="meta-color" type="text" value="<?php if ( isset ( $webdoc_stored_meta['footer-color'] ) ) { echo $webdoc_stored_meta['footer-color'][0]; } else { ?>#1a456d<?php } ?>" class="footer-color" />	
	</p>
	<p>		
		<label for="text-footer-color" class="webdoc-color"><?php _e( 'Couleur du texte du pied de page', 'webdoc' )?></label>		
		<br/>		
		<input name="text-footer-color" class="meta-color" type="text" value="<?php if ( isset ( $webdoc_stored_meta['text-footer-color'] ) ) { echo $webdoc_stored_meta['text-footer-color'][0]; } else { ?>#ffffff<?php } ?>" class="text-footer-color" />	
	</p>
	<p>
		<label for="meta-font" class="webdoc-font"><?php _e( 'Police de caractères (textes)', 'webdoc' )?></label>
		<br/>
	<select name="meta-font" id="meta-font">
        <option value="select-one" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-one' ); ?>><?php _e( 'Arial, Helvetica, sans-serif', 'webdoc' )?></option>
        <option value="select-two" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-two' ); ?>><?php _e( 'Georgia, serif', 'webdoc' )?></option>
		<option value="select-three" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-three' ); ?>><?php _e( 'Tahoma, Geneva, sans-serif', 'webdoc' )?></option>
		<option value="select-four" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-four' ); ?>><?php _e( 'Times New Roman, Times, serif', 'webdoc' )?></option>
		<option value="select-five" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-five' ); ?>><?php _e( 'Verdana, Geneva, sans-serif', 'webdoc' )?></option>
		<option value="select-six" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-six' ); ?>><?php _e( 'Arvo, serif', 'webdoc')?></option>
		<option value="select-seven" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-seven' ); ?>><?php _e( 'DM Sans, sans-serif', 'webdoc' )?></option>
        <option value="select-eight" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-eight' ); ?>><?php _e( 'Open Sans, sans-serif', 'webdoc' )?></option>
		<option value="select-nine" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-nine' ); ?>><?php _e( 'Roboto, sans-serif', 'webdoc' )?></option>
		<option value="select-ten" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-ten' ); ?>><?php _e( 'Roboto Slab, serif', 'webdoc' )?></option>
		<option value="select-eleven" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-eleven' ); ?>><?php _e( 'Lato, sans-serif', 'webdoc' )?></option>
		<option value="select-twelve" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-twelve' ); ?>><?php _e( 'Ubuntu Condensed, sans-serif', 'webdoc' )?></option>
		<option value="select-thirteen" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-thirteen' ); ?>><?php _e( 'Inconsolata, cursive', 'webdoc' )?></option>
		<option value="select-fourteen" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-fourteen' ); ?>><?php _e( 'Playfair Display, serif', 'webdoc' )?></option>
		<option value="select-fifteen" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-fifteen' ); ?>><?php _e( 'Roboto Light, sans-serif', 'webdoc' )?></option>
		<option value="select-sixteen" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-sixteen' ); ?>><?php _e( 'Bree, serif', 'webdoc' )?></option>
		<option value="select-seventeen" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-seventeen' ); ?>><?php _e( 'Oswald regular, sans-serif', 'webdoc' )?></option>
		<option value="select-eighteen" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-heighteen' ); ?>><?php _e( 'Oswal bold, sans-serif', 'webdoc' )?></option>
		<option value="select-nineteen" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-nineteen' ); ?>><?php _e( 'Lobster, cursive', 'webdoc' )?></option>
		<option value="select-twenty" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-twenty' ); ?>><?php _e( 'Lobster Two, cursive', 'webdoc' )?></option>
		<option value="select-twenty-one" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-twenty-one' ); ?>><?php _e( 'Montserrat, sans-serif', 'webdoc' )?></option>
		<option value="select-twenty-two" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-twenty-two' ); ?>><?php _e( 'Montserrat Alternate, sans-serif', 'webdoc' )?></option>
		<option value="select-twenty-three" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'select-twenty-three' ); ?>><?php _e( 'Raleway, sans-serif', 'webdoc' )?></option>
		<option value="belleza" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'bellezza' ); ?>><?php _e( 'Bellezza, serif', 'webdoc' )?></option>
		<option value="poppins" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'poppins' ); ?>><?php _e( 'Poppins, sans-serif', 'webdoc' )?></option>
		<option value="archivo" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'archivo' ); ?>><?php _e( 'Archivo, sans-serif', 'webdoc' )?></option>
		<option value="epilogue" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'epilogue' ); ?>><?php _e( 'Epilogue, sans-serif', 'webdoc' )?></option>
		<option value="nunito" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'nunito' ); ?>><?php _e( 'Nunito, sans-serif', 'webdoc' )?></option>
		<option value="sora" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'sora' ); ?>><?php _e( 'Sora, sans-serif', 'webdoc' )?></option>
		<option value="source" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'source' ); ?>><?php _e( 'Source Sans Pro, sans-serif', 'webdoc' )?></option>
		<option value="lora" <?php if ( isset ( $webdoc_stored_meta['meta-font'] ) ) selected( $webdoc_stored_meta['meta-font'][0], 'lora' ); ?>><?php _e( 'Lora, serif', 'webdoc' )?></option>
	</select>
	</p>
	<p>
		<label for="meta-font_title" class="webdoc-font_title"><?php _e( 'Police de caractères (titres et légende des sections)', 'webdoc' )?></label>
		<br/>
	<select name="meta-font_title" id="meta-font_title">
        <option value="select-zero" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-zero' ); ?>><?php _e( 'Par défaut', 'webdoc' )?></option>
		<option value="select-three" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-three' ); ?>><?php _e( 'Arvo, serif' )?></option>
		<option value="select-one" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-one' ); ?>><?php _e( 'DM Sans, sans-serif' )?></option>
        <option value="select-two" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-two' ); ?>><?php _e( 'Open Sans, sans-serif' )?></option>
		<option value="select-four" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-four' ); ?>><?php _e( 'Roboto, sans-serif' )?></option>
		<option value="select-five" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-five' ); ?>><?php _e( 'Roboto Slab,serif' )?></option>
		<option value="select-six" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-six' ); ?>><?php _e( 'Lato, sans-serif' )?></option>
		<option value="select-seven" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-seven' ); ?>><?php _e( 'Ubuntu Condensed, sans-serif')?></option>
		<option value="select-eight" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-eight' ); ?>><?php _e( 'Inconsolata, cursive' )?></option>
		<option value="select-nine" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-nine' ); ?>><?php _e( 'Playfair Display, serif' )?></option>
		<option value="select-ten" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-ten' ); ?>><?php _e( 'Raleway, sans-serif' )?></option>
		<option value="select-eleven" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-eleven' ); ?>><?php _e( 'Roboto Light, sans-serif' )?></option>
		<option value="select-twelve" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-twelve' ); ?>><?php _e( 'Bree, serif', 'webdoc' )?></option>
		<option value="select-thirteen" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-thirteen' ); ?>><?php _e( 'Oswald regular, sans-serif', 'webdoc' )?></option>
		<option value="select-fourteen" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-fourteen' ); ?>><?php _e( 'Oswal bold, sans-serif', 'webdoc' )?></option>
		<option value="select-fifteen" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-fifteen' ); ?>><?php _e( 'Lobster, cursive', 'webdoc' )?></option>
		<option value="select-sixteen" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-sixteen' ); ?>><?php _e( 'Lobster Two, cursive', 'webdoc' )?></option>
		<option value="select-seventeen" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-seventeen' ); ?>><?php _e( 'Montserrat, sans-serif', 'webdoc' )?></option>
		<option value="select-eighteen" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'select-eighteen' ); ?>><?php _e( 'Montserrat Alternate, sans-serif', 'webdoc' )?></option>
		<option value="belleza" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'belleza' ); ?>><?php _e( 'Bellezza, serif', 'webdoc' )?></option>
		<option value="poppins" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'poppins' ); ?>><?php _e( 'Poppins, sans-serif', 'webdoc' )?></option>
		<option value="archivo" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'archivo' ); ?>><?php _e( 'Archivo, sans-serif', 'webdoc' )?></option>
		<option value="epilogue" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'epilogue' ); ?>><?php _e( 'Epilogue, sans-serif', 'webdoc' )?></option>
		<option value="nunito" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'nunito' ); ?>><?php _e( 'Nunito, sans-serif', 'webdoc' )?></option>
		<option value="sora" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'sora' ); ?>><?php _e( 'Sora, sans-serif', 'webdoc' )?></option>
		<option value="source" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'source' ); ?>><?php _e( 'Source Sans Pro, sans-serif', 'webdoc' )?></option>
		<option value="lora" <?php if ( isset ( $webdoc_stored_meta['meta-font_title'] ) ) selected( $webdoc_stored_meta['meta-font_title'][0], 'lora' ); ?>><?php _e( 'Lora, serif', 'webdoc' )?></option>
	</select>
	</p>		
	
	<p>
	<label for="arrow" class="webdoc-font"><?php _e( 'Type de flèche', 'webdoc' )?></label>
	<br/>
	<select name="arrow" id="arrow">
		<option value="select-one" <?php if ( isset ( $webdoc_stored_meta['arrow'] ) ) selected( $webdoc_stored_meta['arrow'][0], 'select-one' ); ?>><?php _e( 'Chevron', 'webdoc' )?></option>
        <option value="select-two" <?php if ( isset ( $webdoc_stored_meta['arrow'] ) ) selected( $webdoc_stored_meta['arrow'][0], 'select-two' ); ?>><?php _e( 'Short arrow', 'webdoc' )?></option>
		<option value="select-three" <?php if ( isset ( $webdoc_stored_meta['arrow'] ) ) selected( $webdoc_stored_meta['arrow'][0], 'select-three' ); ?>><?php _e( 'Arrow', 'webdoc' )?></option>
		<option value="select-four" <?php if ( isset ( $webdoc_stored_meta['arrow'] ) ) selected( $webdoc_stored_meta['arrow'][0], 'select-four' ); ?>><?php _e( 'Thin chevron', 'webdoc' )?></option>
		<option value="select-five" <?php if ( isset ( $webdoc_stored_meta['arrow'] ) ) selected( $webdoc_stored_meta['arrow'][0], 'select-five' ); ?>><?php _e( 'Thin arrow', 'webdoc' )?></option>
		<option value="select-six" <?php if ( isset ( $webdoc_stored_meta['arrow'] ) ) selected( $webdoc_stored_meta['arrow'][0], 'select-six' ); ?>><?php _e( 'Circle arrow', 'webdoc')?></option>
		<option value="select-seven" <?php if ( isset ( $webdoc_stored_meta['arrow'] ) ) selected( $webdoc_stored_meta['arrow'][0], 'select-seven' ); ?>><?php _e( 'Large arrow', 'webdoc' )?></option>
        <option value="select-eight" <?php if ( isset ( $webdoc_stored_meta['arrow'] ) ) selected( $webdoc_stored_meta['arrow'][0], 'select-eight' ); ?>><?php _e( 'Squared arrow', 'webdoc' )?></option>
		<option value="select-nine" <?php if ( isset ( $webdoc_stored_meta['arrow'] ) ) selected( $webdoc_stored_meta['arrow'][0], 'select-nine' ); ?>><?php _e( 'Light squared arrow', 'webdoc' )?></option>
	</select>
	</p>
	
	<p>		
		<label for="meta-arrow-color" class="webdoc-color"><?php _e( 'Couleur de la flèche', 'webdoc' )?></label>		
		<br/>		
		<input name="meta-arrow-color" class="meta-color" type="text" value="<?php if ( isset ( $webdoc_stored_meta['meta-color'] ) ) { echo $webdoc_stored_meta['meta-arrow-color'][0]; } else { ?>#FFFFFF<?php } ?>" class="meta-arrow-color" />	
	</p>
	
</div>
	
	<div id="tab2" class="ui-sortable meta-box-sortables" style="display:none;">		
	
	<p>		
		<label for="top-bar" class="webdoc-color"><?php _e( 'Couleur d\'arrière-plan de la navbar', 'webdoc' )?></label>		
		<br/>		
		<input name="top-bar" class="meta-color" type="text" value="<?php if ( isset ( $webdoc_stored_meta['top-bar'] ) ) { echo $webdoc_stored_meta['top-bar'][0]; } else { ?>#1a456d<?php } ?>" class="top-bar" />	
	</p>
	<p>		
		<label for="top-bar-text" class="webdoc-color"><?php _e( 'Couleur du texte de la navbar', 'webdoc' )?></label>		
		<br/>		
		<input name="top-bar-text" class="meta-color" type="text" value="<?php if ( isset ( $webdoc_stored_meta['top-bar-text'] ) ) { echo $webdoc_stored_meta['top-bar-text'][0]; } else { ?>#ffffff<?php } ?>" class="top-bar-text" />	
	</p>
	<p>		
		<label for="dynamic-nav" class="webdoc-color"><?php _e( 'Couleur de fond de la navigation dynamique', 'webdoc' )?></label>		
		<br/>		
		<input name="dynamic-nav" class="meta-color" type="text" value="<?php if ( isset ( $webdoc_stored_meta['dynamic-nav'] ) ) { echo $webdoc_stored_meta['dynamic-nav'][0]; } else { ?>#EFEFEF<?php } ?>" class="dynamic-nav" />	
	</p>
	<p>		
		<label for="text-dynamic-nav" class="webdoc-color"><?php _e( 'Texte de la navigation dynamique', 'webdoc' )?></label>		
		<br/>		
		<input name="text-dynamic-nav" class="meta-color" type="text" value="<?php if ( isset ( $webdoc_stored_meta['text-dynamic-nav'] ) ) { echo $webdoc_stored_meta['text-dynamic-nav'][0]; } else { ?>#383838<?php } ?>" class="text-dynamic-nav" />	
	</p>
	
	<p>
	<label for="meta-col" class="webdoc-col"><?php _e( 'Largeur de la colonne de texte', 'webdoc' )?></label>
	<br/>		
	<select name="meta-col" id="meta-col">			
		<option value="select-one" <?php if ( isset ( $webdoc_stored_meta['meta-col'] ) ) selected( $webdoc_stored_meta['meta-col'][0], 'select-one' ); ?>><?php _e( 'Medium', 'webdoc' )?></option>			
		<option value="select-two" <?php if ( isset ( $webdoc_stored_meta['meta-col'] ) ) selected( $webdoc_stored_meta['meta-col'][0], 'select-two' ); ?>><?php _e( 'Large', 'webdoc' )?></option>			
		<option value="select-three" <?php if ( isset ( $webdoc_stored_meta['meta-col'] ) ) selected( $webdoc_stored_meta['meta-col'][0], 'select-three' ); ?>><?php _e( 'Small', 'webdoc' )?></option>			
		<option value="select-four" <?php if ( isset ( $webdoc_stored_meta['meta-col'] ) ) selected( $webdoc_stored_meta['meta-col'][0], 'select-four' ); ?>><?php _e( 'Extra Small', 'webdoc' )?></option>			
	</select>	
	</p>
		<p>		
	<label for="meta-font-size" class="webdoc-font-size"><?php _e( 'Taille du texte', 'webdoc' )?></label>		
	<br/>
	<select name="meta-font-size" id="meta-font-size">
		<option value="select-one" <?php if ( isset ( $webdoc_stored_meta['meta-font-size'] ) ) selected( $webdoc_stored_meta['meta-font-size'][0], 'select-one' ); ?>><?php _e( 'Medium', 'webdoc' )?></option>
		<option value="select-two" <?php if ( isset ( $webdoc_stored_meta['meta-font-size'] ) ) selected( $webdoc_stored_meta['meta-font-size'][0], 'select-two' ); ?>><?php _e( 'Large', 'webdoc' )?></option>			
		<option value="select-three" <?php if ( isset ( $webdoc_stored_meta['meta-font-size'] ) ) selected( $webdoc_stored_meta['meta-font-size'][0], 'select-three' ); ?>><?php _e( 'Small', 'webdoc' )?></option>			
	</select>	
	</p>
	
	
	<p>
	<label for="quote-design" class="quote-design"><?php _e( 'Style des blocs de citation', 'webdoc' )?></label>			
	<select name="quote-design" id="quote-design">				
		<option value="select-one" <?php if ( isset ( $webdoc_stored_meta['quote-design'] ) ) selected( $webdoc_stored_meta['quote-design'][0], 'select-one' ); ?>><?php _e( 'Bordure gauche', 'webdoc' )?></option>				
		<option value="select-two" <?php if ( isset ( $webdoc_stored_meta['quote-design'] ) ) selected( $webdoc_stored_meta['quote-design'][0], 'select-two' ); ?>><?php _e( 'Bordure droite', 'webdoc' )?></option>				
		<option value="select-three" <?php if ( isset ( $webdoc_stored_meta['quote-design'] ) ) selected( $webdoc_stored_meta['quote-design'][0], 'select-three' ); ?>><?php _e( 'Entre guillements (pas de bordure)', 'webdoc' )?></option>				
	</select>	
	</p>			
	
	<p>		
	<label for="quote" class="quote"><?php _e( 'Type de bordure', 'webdoc' )?></label>		
	<select name="quote" id="quote">				
		<option value="select-one" <?php if ( isset ( $webdoc_stored_meta['quote'] ) ) selected( $webdoc_stored_meta['quote'][0], 'select-one' ); ?>><?php _e( 'Couleur du thème', 'webdoc' )?></option>				
		<option value="select-two" <?php if ( isset ( $webdoc_stored_meta['quote'] ) ) selected( $webdoc_stored_meta['quote'][0], 'select-two' ); ?>><?php _e( 'Couleur du thème pointillé', 'webdoc' )?></option>				
		<option value="select-three" <?php if ( isset ( $webdoc_stored_meta['quote'] ) ) selected( $webdoc_stored_meta['quote'][0], 'select-three' ); ?>><?php _e( 'Gris clair', 'webdoc' )?></option>					
		<option value="select-four" <?php if ( isset ( $webdoc_stored_meta['quote'] ) ) selected( $webdoc_stored_meta['quote'][0], 'select-four' ); ?>><?php _e( 'Gris clair pointillé', 'webdoc' )?></option>					
	</select>	
	</p>				
	
</div>
</div>
	<?php
}

function webdoc_meta_save( $post_id ) {     
$is_autosave = wp_is_post_autosave( $post_id );    
$is_revision = wp_is_post_revision( $post_id );    
$is_valid_nonce = ( isset( $_POST[ 'webdoc_nonce' ] ) && wp_verify_nonce( $_POST[ 'webdoc_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }	
			if( isset( $_POST[ 'meta-color' ] ) ) {
				update_post_meta( $post_id, 'meta-color', sanitize_text_field($_POST[ 'meta-color' ]) );
			}	
			if( isset( $_POST[ 'meta-text-color' ] ) ) {
				update_post_meta( $post_id, 'meta-text-color', sanitize_text_field($_POST[ 'meta-text-color' ]) );
			}
			if( isset( $_POST[ 'body-color' ] ) ) {
				update_post_meta( $post_id, 'body-color', sanitize_text_field($_POST[ 'body-color' ]) );
			}
			if( isset( $_POST[ 'footer-color' ] ) ) {
				update_post_meta( $post_id, 'footer-color', sanitize_text_field($_POST[ 'footer-color' ]) );
			}
			if( isset( $_POST[ 'text-footer-color' ] ) ) {
				update_post_meta( $post_id, 'text-footer-color', sanitize_text_field($_POST[ 'text-footer-color' ]) );
			}
			if( isset( $_POST[ 'meta-font' ] ) ) {
				update_post_meta( $post_id, 'meta-font', sanitize_text_field($_POST[ 'meta-font' ]) );
			}
			if( isset( $_POST[ 'meta-font_title' ] ) ) {
				update_post_meta( $post_id, 'meta-font_title', sanitize_text_field($_POST[ 'meta-font_title' ]) );
			} 
			if( isset( $_POST[ 'arrow' ] ) ) {			
				update_post_meta( $post_id, 'arrow', sanitize_text_field($_POST[ 'arrow' ]) );		
			}
			if( isset( $_POST[ 'top-bar' ] ) ) {			
				update_post_meta( $post_id, 'top-bar', sanitize_text_field($_POST[ 'top-bar' ]) );		
			}
			if( isset( $_POST[ 'top-bar-text' ] ) ) {			
				update_post_meta( $post_id, 'top-bar-text', sanitize_text_field($_POST[ 'top-bar-text' ]) );		
			}
			if( isset( $_POST[ 'dynamic-nav' ] ) ) {			
				update_post_meta( $post_id, 'dynamic-nav', sanitize_text_field($_POST[ 'dynamic-nav' ]) );		
			}
			if( isset( $_POST[ 'text-dynamic-nav' ] ) ) {			
				update_post_meta( $post_id, 'text-dynamic-nav', sanitize_text_field($_POST[ 'text-dynamic-nav' ]) );		
			}
			if( isset( $_POST[ 'meta-col' ] ) ) {			
				update_post_meta( $post_id, 'meta-col', sanitize_text_field($_POST[ 'meta-col' ]) );		
			} 
			if( isset( $_POST[ 'meta-font-size' ] ) ) {			
				update_post_meta( $post_id, 'meta-font-size', sanitize_text_field($_POST[ 'meta-font-size' ]) );		
			}
			if( isset( $_POST[ 'quote' ] ) ) {			
				update_post_meta( $post_id, 'quote', sanitize_text_field($_POST[ 'quote' ]) );		
			}
			if( isset( $_POST[ 'quote-design' ] ) ) {			
				update_post_meta( $post_id, 'quote-design', sanitize_text_field($_POST[ 'quote-design' ]) );		
			}
			if( isset( $_POST[ 'meta-arrow-color' ] ) ) {			
				update_post_meta( $post_id, 'meta-arrow-color', sanitize_text_field($_POST[ 'meta-arrow-color' ]) );		
			}
}
add_action( 'save_post', 'webdoc_meta_save' );
//Sections
function webdoc_add_custom_box() {
	global $typenow;
		if( $typenow == 'webdoc' ) {
		  add_meta_box( 'webdoc_editor_footer', __('Bas de page','webdoc'), 'webdoc_editor_footer' );	
		}
}
add_action( 'add_meta_boxes', 'webdoc_add_custom_box' );


//Footer
function webdoc_editor_footer( $post ) { 
	wp_nonce_field( basename( __FILE__ ), 'webdoc_nonce' );
    $webdoc_stored_meta = get_post_meta( $post->ID );
?> 
	<h2 class="title-content"><?php _e('Ajouter le contenu', 'webdoc'); ?></h2>
	<?php	
		$field_value = get_post_meta( $post->ID, '_wp_editor_foot', false );
		
		if ( $field_value == false ) :
			wp_editor( ' ', '_wp_editor_foot' );
		else :
			wp_editor( $field_value[0], '_wp_editor_foot' ); 
		endif;
	?>
	 <p>
        <label for="custom-css" class="webdoc-subline"><?php _e( 'Style additionnel (utilisateur avancé)', 'webdoc' )?></label>
        <br>
		<?php if ( isset ( $webdoc_stored_meta['custom-css'] ) ) { ?><textarea type="text" name="custom-css" class="meta-text-css widefat" id="custom_css" /><?php echo $webdoc_stored_meta['custom-css'][0]; ?></textarea>
		<?php } else { ?><textarea type="text" name="custom-css" class="meta-text-css widefat" id="custom_css" /></textarea>
		<?php } ?>
	</p>
	
<?php }
function webdoc_save_postdata_foot( $post_id ) {
	$is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'webdoc_nonce' ] ) && wp_verify_nonce( $_POST[ 'webdoc_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }
	  if ( isset ( $_POST['_wp_editor_foot'] ) ) {
		update_post_meta( $post_id, '_wp_editor_foot', $_POST['_wp_editor_foot'] );
	  }
	  
	  if ( isset ( $_POST['custom-css'] ) ) {
		update_post_meta( $post_id, 'custom-css', $_POST['custom-css'] );
	  }
}
add_action( 'save_post', 'webdoc_save_postdata_foot' );

/**
 * Generated by the WordPress Meta Box Generator
 * https://jeremyhixon.com/tool/wordpress-meta-box-generator/
 * 
 * Retrieving the values:
 * Titre = get_post_meta( get_the_ID(), 'webdoc_hometitre', true )
 * Image = get_post_meta( get_the_ID(), 'webdoc_homeimage', true )
 * Style = get_post_meta( get_the_ID(), 'webdoc_homestyle', true )
 * Alignement = get_post_meta( get_the_ID(), 'webdoc_homealignement', true )
 */
class webdoc_home {
	private $config = '{"title":"En-tête","prefix":"webdoc_home","domain":"webdoc","class_name":"webdoc_home","post-type":["webdoc"],"context":"normal","priority":"default","cpt":"webdoc","fields":[{"type":"checkbox","label":"Titre","description":"Ne pas afficher le titre sur l\'image","description":"Ne pas afficher le titre sur l\'image","id":"webdoc_hometitre"},{"type":"media","label":"Image","button-text":"Charger","return":"url","modal-title":"Choisir une image","modal-button":"S\u00e9lectionner l\\\u0027image","id":"webdoc_homeimage"},{"type":"select","label":"Mise en forme du titre","options":"option-one : Sans fond de couleur\r\noption-two : Avec fond de couleur","id":"webdoc_homestyle"},{"type":"select","label":"Alignement du titre","default":"Centr\u00e9","options":"option-one : Gauche\r\noption-two : Centr\u00e9\r\noption-three : Droite","id":"webdoc_homealignement"}]}';

	public function __construct() {
		$this->config = json_decode( $this->config, true );
		$this->process_cpts();
		add_action( 'add_meta_boxes', [ $this, 'add_meta_boxes' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_scripts' ] );
		add_action( 'admin_head', [ $this, 'admin_head' ] );
		add_action( 'save_post', [ $this, 'save_post' ] );
	}

	public function process_cpts() {
		if ( !empty( $this->config['cpt'] ) ) {
			if ( empty( $this->config['post-type'] ) ) {
				$this->config['post-type'] = [];
			}
			$parts = explode( ',', $this->config['cpt'] );
			$parts = array_map( 'trim', $parts );
			$this->config['post-type'] = array_merge( $this->config['post-type'], $parts );
		}
	}

	public function add_meta_boxes() {
		foreach ( $this->config['post-type'] as $screen ) {
			add_meta_box(
				sanitize_title( $this->config['title'] ),
				$this->config['title'],
				[ $this, 'add_meta_box_callback' ],
				$screen,
				$this->config['context'],
				$this->config['priority']
			);
		}
	}

	public function admin_enqueue_scripts() {
		global $typenow;
		if ( in_array( $typenow, $this->config['post-type'] ) ) {
			wp_enqueue_media();
		}
	}

	public function admin_head() {
		global $typenow;
		if ( in_array( $typenow, $this->config['post-type'] ) ) {
			?><script>
				jQuery.noConflict();
				(function($) {
					$(function() {
						$('body').on('click', '.rwp-media-toggle', function(e) {
							e.preventDefault();
							let button = $(this);
							let rwpMediaUploader = null;
							rwpMediaUploader = wp.media({
								title: button.data('modal-title'),
								button: {
									text: button.data('modal-button')
								},
								multiple: true
							}).on('select', function() {
								let attachment = rwpMediaUploader.state().get('selection').first().toJSON();
								button.prev().val(attachment[button.data('return')]);
							}).open();
						});
					});
				})(jQuery);
			</script><?php
			?><?php
		}
	}

	public function save_post( $post_id ) {
		foreach ( $this->config['fields'] as $field ) {
			switch ( $field['type'] ) {
				case 'checkbox':
					update_post_meta( $post_id, $field['id'], isset( $_POST[ $field['id'] ] ) ? $_POST[ $field['id'] ] : '' );
					break;
				default:
					if ( isset( $_POST[ $field['id'] ] ) ) {
						$sanitized = sanitize_text_field( $_POST[ $field['id'] ] );
						update_post_meta( $post_id, $field['id'], $sanitized );
					}
			}
		}
	}

	public function add_meta_box_callback() {
		$this->fields_table();
	}

	private function fields_table() {
		?><table class="form-table" role="presentation">
			<tbody><?php
				foreach ( $this->config['fields'] as $field ) {
					?><tr>
						<th scope="row"><?php $this->label( $field ); ?></th>
						<td><?php $this->field( $field ); ?></td>
					</tr><?php
				}
			?></tbody>
		</table><?php
	}

	private function label( $field ) {
		switch ( $field['type'] ) {
			case 'media':
				printf(
					'<label class="" for="%s_button">%s</label>',
					$field['id'], $field['label']
				);
				break;
			default:
				printf(
					'<label class="" for="%s">%s</label>',
					$field['id'], $field['label']
				);
		}
	}

	private function field( $field ) {
		switch ( $field['type'] ) {
			case 'checkbox':
				$this->checkbox( $field );
				break;
			case 'media':
				$this->input( $field );
				$this->media_button( $field );
				break;
			case 'select':
				$this->select( $field );
				break;
			default:
				$this->input( $field );
		}
	}

	private function checkbox( $field ) {
		printf(
			'<label class="rwp-checkbox-label"><input %s id="%s" name="%s" type="checkbox"> %s</label>',
			$this->checked( $field ),
			$field['id'], $field['id'],
			isset( $field['description'] ) ? $field['description'] : ''
		);
	}

	private function input( $field ) {
		if ( $field['type'] === 'media' ) {
			$field['type'] = 'text';
		}
		printf(
			'<input class="regular-text %s" id="%s" name="%s" %s type="%s" value="%s">',
			isset( $field['class'] ) ? $field['class'] : '',
			$field['id'], $field['id'],
			isset( $field['pattern'] ) ? "pattern='{$field['pattern']}'" : '',
			$field['type'],
			$this->value( $field )
		);
	}

	private function media_button( $field ) {
		printf(
			' <button class="button rwp-media-toggle" data-modal-button="%s" data-modal-title="%s" data-return="%s" id="%s_button" name="%s_button" type="button">%s</button>',
			isset( $field['modal-button'] ) ? $field['modal-button'] : __( 'Select this file', 'webdoc' ),
			isset( $field['modal-title'] ) ? $field['modal-title'] : __( 'Choose a file', 'webdoc' ),
			$field['return'],
			$field['id'], $field['id'],
			isset( $field['button-text'] ) ? $field['button-text'] : __( 'Upload', 'webdoc' )
		);
	}

	private function select( $field ) {
		printf(
			'<select id="%s" name="%s">%s</select>',
			$field['id'], $field['id'],
			$this->select_options( $field )
		);
	}

	private function select_selected( $field, $current ) {
		$value = $this->value( $field );
		if ( $value === $current ) {
			return 'selected';
		}
		return '';
	}

	private function select_options( $field ) {
		$output = [];
		$options = explode( "\r\n", $field['options'] );
		$i = 0;
		foreach ( $options as $option ) {
			$pair = explode( ':', $option );
			$pair = array_map( 'trim', $pair );
			$output[] = sprintf(
				'<option %s value="%s"> %s</option>',
				$this->select_selected( $field, $pair[0] ),
				$pair[0], $pair[1]
			);
			$i++;
		}
		return implode( '<br>', $output );
	}

	private function value( $field ) {
		global $post;
		if ( metadata_exists( 'post', $post->ID, $field['id'] ) ) {
			$value = get_post_meta( $post->ID, $field['id'], true );
		} else if ( isset( $field['default'] ) ) {
			$value = $field['default'];
		} else {
			return '';
		}
		return str_replace( '\u0027', "'", $value );
	}

	private function checked( $field ) {
		global $post;
		if ( metadata_exists( 'post', $post->ID, $field['id'] ) ) {
			$value = get_post_meta( $post->ID, $field['id'], true );
			if ( $value === 'on' ) {
				return 'checked value="yes"';
			}
			return '';
		} else if ( isset( $field['checked'] ) ) {
			return 'checked';
		}
		return '';
	}
}
new webdoc_home;

/**
 * Generated by the WordPress Meta Box Generator
 * https://jeremyhixon.com/tool/wordpress-meta-box-generator/
 * 
 * Retrieving the values:
 * Titre = get_post_meta( get_the_ID(), 'chapitre_webdoctitre', true )
 */
class chapitre_webdoc {
	private $config = '{"title":"Chapitre","prefix":"chapitre_webdoc","domain":"webdoc","class_name":"chapitre_webdoc","post-type":["webdoc"],"context":"normal","priority":"default","cpt":"webdoc","fields":[{"type":"text","label":"Titre","id":"chapitre_webdoctitre"}]}';

	public function __construct() {
		$this->config = json_decode( $this->config, true );
		$this->process_cpts();
		add_action( 'add_meta_boxes', [ $this, 'add_meta_boxes' ] );
		add_action( 'save_post', [ $this, 'save_post' ] );
	}

	public function process_cpts() {
		if ( !empty( $this->config['cpt'] ) ) {
			if ( empty( $this->config['post-type'] ) ) {
				$this->config['post-type'] = [];
			}
			$parts = explode( ',', $this->config['cpt'] );
			$parts = array_map( 'trim', $parts );
			$this->config['post-type'] = array_merge( $this->config['post-type'], $parts );
		}
	}

	public function add_meta_boxes() {
		foreach ( $this->config['post-type'] as $screen ) {
			add_meta_box(
				sanitize_title( $this->config['title'] ),
				$this->config['title'],
				[ $this, 'add_meta_box_callback' ],
				$screen,
				$this->config['context'],
				$this->config['priority']
			);
		}
	}

	public function save_post( $post_id ) {
		foreach ( $this->config['fields'] as $field ) {
			switch ( $field['type'] ) {
				default:
					if ( isset( $_POST[ $field['id'] ] ) ) {
						$sanitized = sanitize_text_field( $_POST[ $field['id'] ] );
						update_post_meta( $post_id, $field['id'], $sanitized );
					}
			}
		}
	}

	public function add_meta_box_callback() {
		$this->fields_table();
	}

	private function fields_table() {
		?><table class="form-table" role="presentation">
			<tbody><?php
				foreach ( $this->config['fields'] as $field ) {
					?><tr>
						<th scope="row"><?php $this->label( $field ); ?></th>
						<td><?php $this->field( $field ); ?></td>
					</tr><?php
				}
			?></tbody>
		</table><?php
	}

	private function label( $field ) {
		switch ( $field['type'] ) {
			default:
				printf(
					'<label class="" for="%s">%s</label>',
					$field['id'], $field['label']
				);
		}
	}

	private function field( $field ) {
		switch ( $field['type'] ) {
			default:
				$this->input( $field );
		}
	}

	private function input( $field ) {
		printf(
			'<input class="regular-text %s" id="%s" name="%s" %s type="%s" value="%s">',
			isset( $field['class'] ) ? $field['class'] : '',
			$field['id'], $field['id'],
			isset( $field['pattern'] ) ? "pattern='{$field['pattern']}'" : '',
			$field['type'],
			$this->value( $field )
		);
	}

	private function value( $field ) {
		global $post;
		if ( metadata_exists( 'post', $post->ID, $field['id'] ) ) {
			$value = get_post_meta( $post->ID, $field['id'], true );
		} else if ( isset( $field['default'] ) ) {
			$value = $field['default'];
		} else {
			return '';
		}
		return str_replace( '\u0027', "'", $value );
	}

}
new chapitre_webdoc;

function webdoc_header_get_meta( $value ) {
	global $post;

	$field = get_post_meta( $post->ID, $value, true );
	if ( ! empty( $field ) ) {
		return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );
	} else {
		return false;
	}
}

function webdoc_header_add_meta_box() {
	$types = array('webdoc');
	
	foreach( $types as $type )
    {
		add_meta_box(
			'webdoc_header-webdoc_header',
			__( 'Titraille (contenu)', 'webdoc' ),
			'webdoc_header_html',
			$type,
			'normal',
			'default'
		);
	}
}
add_action( 'add_meta_boxes', 'webdoc_header_add_meta_box' );

function webdoc_header_html( $post) {
	wp_nonce_field( '_webdoc_header_nonce', 'webdoc_header_nonce' ); 
	
	$checkboxMeta = get_post_meta( $post->ID ); ?>

	<p style="font-weight:bold;"><?php _e('Cocher cette case pour afficher le titre en tête d\'article','webdoc'); ?> 
	
	

		<input type="checkbox" name="webdoc_header_une" id="webdoc_header_une" value="yes" <?php if ( isset ( $checkboxMeta['webdoc_header_une'] ) ) checked( $checkboxMeta['webdoc_header_une'][0], 'yes' ); ?> />
	</p>
	
	<p style="font-weight:bold;"><?php _e('Cocher cette case pour afficher l\'extrait (résumé facultatif) comme chapeau  tête d\'article','webdoc'); ?> 
	
		<input type="checkbox" name="chapeau" id="chapeau" value="yes" <?php if ( isset ( $checkboxMeta['chapeau'] ) ) checked( $checkboxMeta['chapeau'][0], 'yes' ); ?> />
	</p>
		<?php
}

function webdoc_header_save( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! isset( $_POST['webdoc_header_nonce'] ) || ! wp_verify_nonce( $_POST['webdoc_header_nonce'], '_webdoc_header_nonce' ) ) return;
	if ( ! current_user_can( 'edit_post', $post_id ) ) return;

	 if( isset( $_POST[ 'webdoc_header_une' ] ) ) {
        update_post_meta( $post_id, 'webdoc_header_une', 'yes' );
    } else {
        update_post_meta( $post_id, 'webdoc_header_une', 'no' );
    }
	if( isset( $_POST[ 'chapeau' ] ) ) {
        update_post_meta( $post_id, 'chapeau', 'yes' );
    } else {
        update_post_meta( $post_id, 'chapeau', 'no' );
    }
}
add_action( 'save_post', 'webdoc_header_save' );
?>
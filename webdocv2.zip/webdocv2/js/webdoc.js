var $ = jQuery.noConflict();
$(document).ready(function() {
  
        $("#open").click(function() {
            $("#menuleft").show().animate({
                    left: "+=310px"
                }, "slow"), $("#open").hide(), $("#closed").show();
			$('body').addClass('scroll');
			$('#overlay').show();
        });
		
        $("#closed").click(function() {
            $("#menuleft").show().animate({
                    left: "-310px"
                }, "slow"),$("#open").show(), $("#closed").hide();
			$('body').removeClass('scroll');
			$('#overlay').hide();
        });
		
		$("#openi").click(function() {
			$('#intranav').css('visibility','visible');
			$('#intranav').slideDown();
			$("#openi").hide();
			$("#closedi").show();
        });
		
		$("#closedi").click(function() {
            $('#intranav').css('visibility','hidden');
			$('#intranav').slideUp();
			$("#openi").show();
			$("#closedi").hide();
        });
		
        $(window).scroll(function() {
             if($(window).scrollTop() > 100) {
				 $("#menu").slideDown();
				 $('body').removeClass('scroll');
			 }
			else {		   
				$("#menu").slideUp();
				$('body').addClass('scroll');
			}
        });
		
        $("#more a").click(function() {
            $("#menu").slideDown();
			$('body').removeClass('scroll');
        });
		
		$('.scrollTo').click( function() { 
			var page = $(this).attr('href'); 
			var speed = 750; 
			$('html, body').animate( { scrollTop: $(page).offset().top }, speed ); 
			return false;
		}),
		
        ($.fn.isInViewport = function() {
            let e = $(this).offset().top,
                o = e + $(this).outerHeight(),
                t = $(window).scrollTop(),
                n = t + $(window).height();
            return o > t && e < n;
        });
		
        $("body").keydown(function(e) {
            if (e.keyCode==40 && $("#main-title h1").isInViewport() ) {
				$("#more a").trigger("click");
			}
        });
		
		var v = jQuery('[src^="https://www.youtube.com/embed/"]');
		v.wrap('<div class = "ratio ratio-16x9">');

		var w = jQuery('[src^="https://player.vimeo.com"]');
		w.wrap('<div class = "ratio ratio-16x9">');
		
		$('#section2 img').unwrap('p');
		

		function autoResize(iframe) {
			$(iframe).height($(iframe).contents().find('html').height());
		}
	
});
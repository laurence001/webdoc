<?php
/*
Plugin Name: Webdoc
Plugin URI: https://www.journodev.tech
Description: Un outil pour créer des webdocumentaires avec Wordpress.
Version: 1.1
Author: laurence/OhMyBox.info
Author URI: https://journodev.tech
Text domain: webdoc
Domain Path: /languages/
License: GPL2

Webdoc is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
Webdoc  is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
*/

if ( ! defined( 'ABSPATH' ) ) exit; 

function webdoc_init() {
	load_plugin_textdomain( 'webdoc', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );
}

add_action('init', 'webdoc_init');

	$plugin_dir_path = plugin_dir_path( __FILE__ );
	include( $plugin_dir_path . 'inc/webdoc-init.php');
	include( $plugin_dir_path . 'inc/webdoc-metabox.php');
	include( $plugin_dir_path . 'inc/webdoc-functions.php');
	include( $plugin_dir_path . 'inc/webdoc-duplicate.php');
	include( $plugin_dir_path . 'inc/webdoc-front.php');
	include( $plugin_dir_path . 'inc/webdoc-options.php');
?>